﻿namespace SoftJail.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-LOVERHL\MSSQLSERVER11;;Database=SoftJail;Trusted_Connection=True";
    }
}
